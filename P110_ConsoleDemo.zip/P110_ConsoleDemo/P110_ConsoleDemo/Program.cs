﻿using System;

namespace P110_ConsoleDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            #region try catch finally
            //string number = "123";
            //try
            //{
            //    int a = int.Parse(number);
            //    Console.WriteLine(a);
            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine(number + " duzgun reqem deyil");
            //}
            //finally
            //{
            //    Console.WriteLine("Yuxarida try ve ya catch icra edildi.");
            //}
            #endregion

            Console.WriteLine("Input a number:");
            string input = Console.ReadLine();

            int result;
            bool hasConverted = TryParseInt(input, out result);

            while(!hasConverted)
            {
                Console.WriteLine("Please, input valid number.");
                input = Console.ReadLine();
                hasConverted = TryParseInt(input, out result);
            }

        }

        static bool TryParseInt(string s, out int n)
        {
            try
            {
                n = int.Parse(s);
                return true;
            }
            catch
            {
                n = 0;
                return false;
            }
        }

        static void ChangeCharacter(out char a)
        {
            Console.WriteLine("sdf");
            a = '.';
        }

        static void ChangeNumber(ref int n)
        {
            n = 100;
        }

        #region Overloading methods
        //method overloading
        //method signature - imza (method name, method parameters count, method parameters types)


        /// <summary>
        /// Calculates 2 integer numbers with the specified operation
        /// </summary>
        /// <param name="n1">First integer</param>
        /// <param name="n2">Second integer</param>
        /// <param name="operation">Operation to be applied to numbers. Default is +</param>
        /// <returns>Returns the result of operation.</returns>
        //static int Calculate(int n1, int n2, char operation = '+')
        //{
        //    switch (operation)
        //    {
        //        case '+':
        //            return n1 + n2;
        //        case '-':
        //            return n1 - n2;
        //        case '*':
        //            return n1 * n2;
        //        case '/':
        //            return n1 / n2;
        //        default:
        //            throw new ArgumentException("Operation is not valid");
        //    }
        //}

        //static string Concat(string line1, string line2)
        //{
        //    return $"Result string: {line1} {line2}";
        //}

        //static string Concat(string line, int count)
        //{
        //    string result = "";
        //    for (int i = 0; i < count; i++)
        //    {
        //        result += line;
        //    }

        //    return result;
        //}

        //static string Concat(string line1, string line2, string line3)
        //{
        //    return $"{line1} {line2} {line3}";
        //}

        //static string Concat(params string[] words)
        //{
        //    string result = "";
        //    for (int i = 0; i < words.Length; i++)
        //    {
        //        result += words[i];
        //    }

        //    return result;
        //}
        #endregion
    }

    class Person { }
    class Man : Person { }
}
